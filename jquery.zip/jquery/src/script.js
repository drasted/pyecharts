;
(function($, undefined) {

  /**
   * @constructor
   * @param {string | jQuery} poster 选择器或jQuery实例
   * @param {Object} [options] 可选设置
   */
  function RoundSlide(poster, options) {
    var self = this;
    var onPause;
    
    this.poster = $(poster);
    
    // jq工具方法。对参数一json中的属性，参数二json中有与参数一json中相同的属性，则替换参数一中的属性；若参数二json中有参数一json中所没有的属性，则追加到参数一。简言之，用参数二的属性，追加或替换参数一的属性。
    this.setting = $.extend({}, this.defaults, this.getOptions(), typeof options === 'object' && options);
    
    this.frameWrapper = poster.find('ul.poster-list');
    this.btn = poster.find('.poster-btn');
    this.frames = this.frameWrapper.find('li');
    this.firstFrame = this.frames.eq(0);
    this.lastFrame = this.frames.eq(-1);
    this.isMoving = false;
    this.timer = null;
    this.size = this.frames.length;
    
    this.setPosterSize();
    this.setPosterPos();

    // 点击前一张或下一张的按钮事件触发时，调用goPrevOrNext方法
    // 通过isMoving属性限定图片动画停止时，才调用goPrevOrNext方法
    // 如果图片动画进行时调用goPrevOrNext方法，则图片的css样式会被打乱
    this.btn.filter('.poster-btn-prev').on('click', function() {
      self.goPrevOrNext('prev');
    });
    this.btn.filter('.poster-btn-next').on('click', function() {
      self.goPrevOrNext('next');
    });

    if (this.setting.autoPlay) {
      this.autoPlay();
      this.poster.hover(function() {
        self.stopPlay();
      }, function() {
        self.autoPlay();
      })
    }

  };

  RoundSlide.prototype = {
    constructor: RoundSlide,
    
    // 默认设置
    defaults: {
      "width": 1000, // 容器总宽
      "height": 270, // 容器总高
      "frameWidth": 640, // 当前帧的宽
      "frameHeight": 270, // 当前帧的高
      "scale": 0.9, // 非当前帧按此比例等比缩小
      "dur": 500, // 切换帧过渡时长
      "autoPlay": true, // 是否自动播放
      "interval": 3000, // 相邻两次切换之间间隔时长
      
      // 垂直对齐的位置，可以是 'top' or 'bottom' or 'middle'，
      // 默认底部对齐
      "vAlign": "bottom", 
      
      // 轮播一暂停立即回调
      "onPause": null
    },

    // 获取写在元素属性中的可选设置
    getOptions: function() {

      var setting = this.poster.attr('data-setting');
      if (setting && setting !== '') {
        return $.parseJSON(setting);
      } else {
        return null;
      }

    },

    // 设置容器、当前帧（最前面的）的样式
    setPosterSize: function() {
      // poster的宽高
      this.poster.css({
        width: this.setting.width,
        height: this.setting.height
      });
      // 设置图片容器的宽高
      this.frameWrapper.css({
        width: this.setting.frameWidth,
        height: this.setting.frameHeight
      });

      // 设置左右切换按钮的宽高
      var w = Math.floor((this.setting.width - this.setting.frameWidth) / 2);
      var framesLength = this.frames.size();

      this.btn.css({
        width: w,
        height: this.setting.frameHeight,
        'z-index': Math.ceil(framesLength / 2)
      });

      // 设置当前帧的尺寸
      this.firstFrame.css({
        width: this.setting.frameWidth,
        height: this.setting.frameHeight,
        left: w,
        zIndex: Math.floor(framesLength / 2)
      });

    },

    // 设置剩余帧的位置
    setPosterPos: function() {
      var self = this;
      var scale = this.setting.scale;
      // 取出除第一张之外的帧
      // 从下标一开始取
      var slicedFrames = this.frames.slice(1),
        // 若余下的帧为偶数，则可以左右对称；若为奇数，则不对称
        slicedRightSize = slicedFrames.size() % 2 === 0 ?
        Math.floor(slicedFrames.size() / 2) : Math.ceil(slicedFrames.size() / 2),
        slicedRight = slicedFrames.slice(0, slicedRightSize),
        slicedLeft = slicedFrames.slice(slicedRightSize),
        slicedLeftSize = slicedLeft.size(),
        zIndex = slicedRightSize;

      var ow = this.setting.frameWidth,
        oh = this.setting.frameHeight,
        originLeft = (this.setting.width - this.setting.frameWidth) / 2,
        gap = originLeft / slicedRightSize,
        gapLeft = originLeft / slicedLeftSize;

      function setTop(h) {
        var str = self.setting.vAlign;
        var top = 0;
        switch (str) {
          case 'middle':
            top = (oh - h) / 2;
            break;
          case 'bottom':
            top = oh - h;
            break;
          case 'top':
            top = 0;
            break;
        }
        return top;
      }

      // 设置右边帧的位置
      var rw = ow,
        rh = oh;
      slicedRight.each(function(i) {
        var n = i + 1;
        // 从左到右递减
        zIndex--;
        rw = scale * rw;
        rh = scale * rh;
        $(this).css({
          zIndex: zIndex,
          width: rw,
          height: rh,
          opacity: 1 / n,
          left: originLeft + ow + n * gap - rw,
          top: setTop(rh)
        });

      });

      // 设置左边帧的位置
      var lw = rw,
        lh = rh;
      var opacityBase = slicedLeftSize;
      slicedLeft.each(function(i) {
        $(this).css({
          // 从左到右递增
          zIndex: i,
          width: lw,
          height: lh,
          opacity: 1 / opacityBase,
          left: i * gapLeft,
          top: setTop(lh)
        });
        lw = lw / scale;
        lh = lh / scale;
        opacityBase--;
      })
    },
    
    /**
     * @param {string} direction 前一帧或下一帧
     * @param {Function} cb 轮播一暂停立即回调
     */
    goPrevOrNext: function(direction, cb) {
      // 上锁，动画进行中，点击按钮时不调用方法
      if (this.isMoving) return false;
      this.isMoving = true;
      var 
        self = this,
        first = this.firstFrame,
        last = this.lastFrame,
        dur = this.setting.dur;
      var 
        d = direction,
        zIndexNext = [],
        zIndexPrev = [];
      cb || (cb = this.setting.onPause);

      this.frames.each(function(i, val) {
        var next;
        var $this = $(val);
        
        // 下一帧 next ，当前帧过渡到成为前一帧的样式
        // 上一帧 prev ，当前帧过渡到成为下一帧的样式
        if (d === 'prev') {
          next = ( next = $this.next() )[0] ? next : first;
        } else if (d === 'next') {
          next = ( next = $this.prev() )[0] ? next : last;
        }

        var target = {
          // zIndex: next.css('zIndex'),
          width: next.width(),
          height: next.height(),
          opacity: next.css('opacity'),
          left: next.css('left'),
          top: next.css('top')
        };
        zIndexNext.push(next.css('zIndex'));
        $this.animate(target, dur, function() {
          if (i === self.size - 1) {
            self.isMoving = false;
            typeof cb === 'function' && cb.apply(self);
            // console.log(self.findCurFrame().index);
          }

        });
      }).each(function(i) {
        $(this).css({
          zIndex: zIndexNext[i]
        });
      });

    },
    
    // @public
    goPrev: function () {
      return this.goPrevOrNext('prev');
    },
    
    // @public
    goNext: function () {
      return this.goPrevOrNext('next');
    },

    autoPlay: function() {
      var self = this;
      this.timer = setInterval(function() {
        self.btn.filter('.poster-btn-next')[0].click();
      }, self.setting.interval);
    },

    stopPlay: function() {
      clearInterval(this.timer);
      this.timer = null;
    },

    findCurFrame: function() {
      var maxhFrame;
      var maxFrameIndex;
      var maxH;
      this.frames.each(function(index, frame) {
        var $frame = $(frame);
        var h = $frame.height();
        if (index > 0) {
          if (h >= maxH) {
            maxH = h;
            maxhFrame = $frame;
            maxFrameIndex = index;
          }
        } else {
          maxH = h;
          maxhFrame = $frame;
          maxFrameIndex = index;
        }

      })
      return {
        $el: maxhFrame,
        index: maxFrameIndex
      }
    }
  };
  
  var plugin = function(options) {
    return this.each(function() {
      var $this = $(this);
      var roundSlide = $this.data('roundSlide')
      if (!roundSlide) {
        $this.data( 'roundSlide',( roundSlide = new RoundSlide($this, options) ) );
      }
      
      if (options == 'prev') roundSlide.goPrev();
      if (options == 'next') roundSlide.goNext();
    })
  }

  // 将插件注册到`jQuery.fn`
  $.fn.roundSlide = plugin;
  $.fn.roundSlide.Constructor = RoundSlide;
  $('[data-roundSlide1]').roundSlide();
})(jQuery);

$(function() {
  $('.poster-main').eq(0).roundSlide({
    "width": 960,
    "height": 225,
    "frameWidth": 400,
    "frameHeight": 225,
    "scale": 0.8,
    "dur": 300,
    "vAlign": "middle",
    "interval": 5000,
    onPause: function() {
      console.log('pause');
    }
  });
  
  // 证明插件的实例存储在dom元素的data中
  var roundSlide = $('.poster-main').data('roundSlide');
  
  $('.poster-main').eq(1).roundSlide({
    "width": 960,
    "height": 225,
    "frameWidth": 400,
    "frameHeight": 225,
    "dur": 1800,
    "vAlign": "top",
    "interval": 4000,
    onPause: function() {
      console.log('pause');
    }
  });
})